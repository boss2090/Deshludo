import 'package:flutter/material.dart';

class LudoToken {
  int position;
  final Color color;

  LudoToken({required this.position, required this.color});
}
